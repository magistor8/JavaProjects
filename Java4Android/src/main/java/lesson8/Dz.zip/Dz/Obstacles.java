package lesson8.Dz;

public interface Obstacles  {

    boolean run(Party member);
    boolean jump(Party member);
}
