package lesson8.Dz;

public interface Party {

    void jump();
    void run();
    String getType();
    String getName();
    int getMaxRunningLength();
    int getMaxJumpHeight();

}
